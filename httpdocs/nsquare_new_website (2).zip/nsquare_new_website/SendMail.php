<?php
 
 require_once('class.phpmailer.php');
 require 'PHPMailerAutoload.php';
 //require_once 'contents.html';



		$to = "enquiry@Nsquarexperts.com";
         $subject = "Contact Enquiry";
		 $body="Dear Team,<br>
				we have below enquiry
				First Name :".$_POST['user-name']."<br>
				Last Name :	".$_POST['user-lastname']."<br>
				Email :	".$_POST['user-email']."<br>
				Description :".$_POST['enquiry_type']."
				<br><br> Thank You.";
		$subject='Enquiry';
		 $emailid='enquiry@nsquarexperts.com';

		$mail = new PHPMailer(); // create a new object
		$mail->IsSMTP(); // set mailer to use SMTP
		$mail -> SMTPSecure = 'ssl';// secure transfer enabled REQUIRED for Gmail
		$mail->Port = 465; // or 587
		$mail -> Host = 'ssl://smtp.gmail.com';
		$mail->SMTPAuth = true; // turn on SMTP authentication
		$mail->Username = 'nsquarexperts28@gmail.com';                 // SMTP username
		$mail->Password = 'nsquare2017';                           // SMTP password
		$mail->From 	= 'nsquarexperts28@gmail.com';
		$mail->FromName = 'Nsquarexperts';
		
		$mail->addAddress('pritam.kirdat@nsquarexperts.com', ''); // Add a recipient
		//$mail->addBCC('pratik@nsquarexperts.com');
		$mail->addBCC('pritam.kirdat@nsquarexperts.com');
		
		$mail->addReplyTo('info@example.com', 'Information');
		//$mail->addCC('abhinayphuke@gmail.com');
		$mail->isHTML(true);                                  // Set email format to HTML
		$mail->Subject =$subject;
		$mail->Body    = $body;
		
		if(!$mail->send()) {
		  	header('location:contact_us.html');
		} else {
		   header('location:contact_us.html?msg=sent');
		}
    

?>
