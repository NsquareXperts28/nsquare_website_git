
<?php
#---------For Testing PHPMailer is installed correctly Or not-------
require("class.phpmailer.php");
$mail = new PHPMailer();
?>