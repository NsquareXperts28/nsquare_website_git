<?php
phpinfo();

?>
